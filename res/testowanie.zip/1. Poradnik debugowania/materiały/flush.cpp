#include <iostream>
using namespace std;

int main() {
    for (int i = 0; i < 100; i++) {
        cout << i << " ";
    }    
    cout << 5 % 0 << endl;
    return 0;
}
