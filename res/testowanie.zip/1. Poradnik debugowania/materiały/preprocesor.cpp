#include <iostream>
using namespace std;

#define MULTIPLY(a, b) a * b

int main() {
    cout << MULTIPLY(2 + 2, 2) << endl;
}
